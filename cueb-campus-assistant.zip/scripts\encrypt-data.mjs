import crypto from "crypto";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "..", "data");

const KEY_HEX = process.env.DATA_ENCRYPTION_KEY;
if (!KEY_HEX) {
  console.error("Set DATA_ENCRYPTION_KEY env var first");
  process.exit(1);
}
const key = Buffer.from(KEY_HEX, "hex");

function encryptFile(filename) {
  const src = path.join(dataDir, filename);
  const dst = path.join(dataDir, filename.replace(".json", ".enc"));
  const plaintext = fs.readFileSync(src, "utf8");
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  let encrypted = cipher.update(plaintext, "utf8", "base64");
  encrypted += cipher.final("base64");
  const authTag = cipher.getAuthTag();
  const blob = [iv.toString("base64"), authTag.toString("base64"), encrypted].join(".");
  fs.writeFileSync(dst, blob, "utf8");
  console.log(`Encrypted ${filename} -> ${filename.replace(".json", ".enc")}`);
}

encryptFile("students.json");
encryptFile("schedules.json");
console.log("Done. You can now delete the plaintext .json files.");
